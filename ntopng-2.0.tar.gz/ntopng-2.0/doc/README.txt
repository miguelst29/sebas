Documentation is generated using the doxygen tool that uses graphviz for drawing graphs.

In order to generate Lua docs you need to install
https://github.com/alecchen/doxygen-lua
as follows:
   cpan App::cpanminus
   cpan inc::Module::Install
   git clone https://github.com/alecchen/doxygen-lua.git
   cd doxygen-lua/
   perl Makefile.PL 
   make 
   sudo make install
   sudo cp bin/lua2dox /opt/local/bin/   
