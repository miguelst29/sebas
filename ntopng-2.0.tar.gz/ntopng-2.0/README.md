# ntopng
ntopng is a web-based network traffic monitoring application released under GPLv3. It is the new incarnation of the original ntop written in 1998, and now revamped in terms of performance, usability, and features.

While you can read more about ntopng on the ntop web site (http://www.ntop.org), we suggest you to start reading the doc/README.ntopng file for learning how to compile and use ntopng.

If instead of source code you prefer to use a pre-built package, please go to http://packages.ntop.org

We build binary packages for the following platforms:
* Ubuntu Linux Server x64
* CentOS/RedHat Linux x64
* Windows x64
* BeagleBoard ARM (based on Ubuntu Linux)
* Ubiquity Networks EdgeRouter (MIPS)

Enjoy.